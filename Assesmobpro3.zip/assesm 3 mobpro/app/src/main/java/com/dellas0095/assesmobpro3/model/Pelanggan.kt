package com.dellas0095.assesmobpro3.model

data class Pelanggan(
    val id: String,
    val namaPelanggan: String,
    val variant: String,
    val warna: String,
    val imageId: String,
    val mine: String
)