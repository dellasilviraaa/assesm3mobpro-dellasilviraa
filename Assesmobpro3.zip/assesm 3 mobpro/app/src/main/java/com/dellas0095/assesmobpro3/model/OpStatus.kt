package com.dellas0095.assesmobpro3.model

data class OpStatus(
    var status: String,
    var message: String?
)
