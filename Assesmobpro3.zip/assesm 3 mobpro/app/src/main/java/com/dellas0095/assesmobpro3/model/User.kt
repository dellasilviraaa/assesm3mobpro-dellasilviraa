package com.dellas0095.assesmobpro3.model

import android.provider.ContactsContract.CommonDataKinds.Email

data class User(
    val name: String ="",
    val email: String ="",
    val photoUrl: String =""
)
